/**
 * Created by onur on 01.06.17.
 */

export class Tab {
  selectedTab: number;
}
