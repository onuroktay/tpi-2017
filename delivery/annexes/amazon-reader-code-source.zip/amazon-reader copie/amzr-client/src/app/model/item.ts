/**
 * Created by onur on 01.06.17.
 */

export class Item {
  id: string;
  title: string;
  price: number;
  imUrl: string;
}
