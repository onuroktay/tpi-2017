/**
 * Created by onur on 01.06.17.
 */

export class UserRole {
  roleName: string;
  roleValue: number;
}
