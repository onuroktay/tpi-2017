/**
 * Created by onur on 01.06.17.
 */

export class Role {
  id: string;
  name: string;
}
