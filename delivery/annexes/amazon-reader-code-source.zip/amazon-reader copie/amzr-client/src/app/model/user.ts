/**
 * Created by onur on 01.06.17.
 */


export class User {
  id: string;
  username: string;
  roleValue: number;
}
