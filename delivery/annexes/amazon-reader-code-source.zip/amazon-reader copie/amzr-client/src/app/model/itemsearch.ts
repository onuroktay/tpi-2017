/**
 * Created by onur on 01.06.17.
 */

export class ItemSearch {
  category: string;
  title: string;
  priceFrom: string;
  priceTo: string;
  size: number;
  from: number;
}
