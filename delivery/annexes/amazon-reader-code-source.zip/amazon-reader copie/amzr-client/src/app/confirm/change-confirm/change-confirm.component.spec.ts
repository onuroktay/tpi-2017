// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
//
// import { ChangeConfirmComponent } from './change-confirm.component';
//
// describe('ChangeConfirmComponent', () => {
//   let component: ChangeConfirmComponent;
//   let fixture: ComponentFixture<ChangeConfirmComponent>;
//
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ChangeConfirmComponent ]
//     })
//     .compileComponents();
//   }));
//
//   beforeEach(() => {
//     fixture = TestBed.createComponent(ChangeConfirmComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });
//
//   it('should be created', () => {
//     expect(component).toBeTruthy();
//   });
// });
