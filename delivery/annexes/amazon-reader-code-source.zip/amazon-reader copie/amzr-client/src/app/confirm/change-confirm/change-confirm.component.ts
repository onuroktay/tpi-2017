import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'amzr-change-confirm',
  templateUrl: './change-confirm.component.html',
  styleUrls: ['./change-confirm.component.css']
})
export class ChangeConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
