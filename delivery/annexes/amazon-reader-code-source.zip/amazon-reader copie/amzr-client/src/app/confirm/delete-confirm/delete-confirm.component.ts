import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'amzr-delete-confirm',
  templateUrl: './delete-confirm.component.html',
  styleUrls: ['./delete-confirm.component.css']
})
export class DeleteConfirmComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }


}
